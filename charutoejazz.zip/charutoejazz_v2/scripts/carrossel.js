$(document).ready(function(){
    $('.carousel').slick({
        autoplay: true, // Define para reproduzir automaticamente
        autoplaySpeed: 5000, // Velocidade de troca dos slides (em milissegundos)
        arrows: false, // Exibe botões de navegação (setas)
        dots: true, // Exibe os pontos de navegação
        infinite: true, // Define para criar um loop contínuo
        slidesToShow: 1, // Quantidade de slides visíveis
        slidesToScroll: 1 // Quantidade de slides a serem trocados de cada vez
    });
});